import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'my-input',
  templateUrl: './my-input.component.html',
  styleUrls: ['./my-input.component.css']
})
export class MyInputComponent implements OnInit {

  constructor() { }
  @Input() Placeholder: string;
  @Input() InputValue: string = "";
  @Output() InputValueChanged = new EventEmitter();

  InputValueChanging($event){
    this.InputValue = $event.target.value;
    this.InputValueChanged.emit(this.InputValue);
  }

  ngOnInit() {
  }
}