import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import {  MatButtonModule, MatToolbarModule, MatInputModule } from '@angular/material';



@NgModule({
  imports: [MatButtonModule, MatToolbarModule, MatInputModule],
  exports: [MatButtonModule, MatToolbarModule, MatInputModule],
  declarations: []
})
export class MaterialAppModule { }